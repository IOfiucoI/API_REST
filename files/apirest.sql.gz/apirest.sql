-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 25-01-2023 a las 03:16:09
-- Versión del servidor: 5.7.36
-- Versión de PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `apirest`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `becas`
--

DROP TABLE IF EXISTS `becas`;
CREATE TABLE IF NOT EXISTS `becas` (
  `id_apoyos` int(10) NOT NULL AUTO_INCREMENT,
  `id_institucion` int(10) DEFAULT NULL,
  `programa` varchar(40) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `periodo` varchar(50) DEFAULT NULL,
  `documento` varchar(40) DEFAULT NULL,
  `institucionesid_institucion` int(10) NOT NULL,
  PRIMARY KEY (`id_apoyos`),
  KEY `FKbecas429758` (`institucionesid_institucion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carreras`
--

DROP TABLE IF EXISTS `carreras`;
CREATE TABLE IF NOT EXISTS `carreras` (
  `id_carrera` int(10) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) DEFAULT NULL,
  `resenia` varchar(500) DEFAULT NULL,
  `objetivo` varchar(500) DEFAULT NULL,
  `mision` varchar(500) DEFAULT NULL,
  `vision` varchar(500) DEFAULT NULL,
  `porque` varchar(500) DEFAULT NULL,
  `perfil_ingreso` varchar(2000) DEFAULT NULL,
  `perfil_egreso` varchar(2000) DEFAULT NULL,
  `campo_laboral` varchar(2000) DEFAULT NULL,
  `institucionesid_institucion` int(10) NOT NULL,
  PRIMARY KEY (`id_carrera`),
  KEY `FKcarreras18801` (`institucionesid_institucion`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `carreras`
--

INSERT INTO `carreras` (`id_carrera`, `nombre`, `resenia`, `objetivo`, `mision`, `vision`, `porque`, `perfil_ingreso`, `perfil_egreso`, `campo_laboral`, `institucionesid_institucion`) VALUES
(1, 'Sistemas computacionales', 'En agosto del 2007 el Instituto Tecnológico Superior de Zongolica oferta por primera vez la carrera de Ingeniería en Sistemas Computacionales teniendo una demanda para esta primera generación de 40 alumnos de los diferentes municipios de la zona centro. Todo ello, con la finalidad de que nuestros egresados sean los precursores de la innovación tecnológica en la región.\r\n\r\nCon esta carrera el ITSZ se muestra encaminado al amplio mundo de la informática y la tecnología con la única finalidad de eg', 'Formar profesionistas líderes, analíticos, críticos y creativos, con visión estratégica y amplio sentido ético, capaces de diseñar, implementar y administrar infraestructura computacional para aportar soluciones innovadoras en beneficio de la sociedad, en un contexto global, multidisciplinario y sustentable.', 'Formar profesionistas de calidad en ingeniería en sistemas computacionales bajo el modelo educativo emprende innovador, capaces de analizar situaciones, entornos y problemas que necesiten de soluciones integrales desde el análisis, desarrollo e implementación de sistemas informáticos y nuevas tecnologías, fundamentadas en la sustentabilidad con apego a la sociedad del estado de Veracruz y el resto del país.', 'Ser la primera ingeniería emprende innovadora en la gestión e implementación de empresas que brinden soluciones informáticas y desarrollo de tecnologías en todos los sectores productivos del país, con un alto compromiso social y valores de sus egresados.', 'Es un profesionista capaz de analizar situaciones, entornos y problemas propios de ser tratados mediante sistemas computaciones, para ofrecer soluciones completas resultantes de la creación, adecuación, integración o selección de productos y servicios computacionales.', 'Conocimientos fundamentales adquiridos en el nivel bachillerato: matemáticas, física, química.\r\nRazonamiento lógico-matemático.\r\nHabilidades de interacción y comunicación.\r\nCapacidades de comunicación oral, escrita, análisis, síntesis, integración al trabajo en equipo y gusto por la investigación.\r\nRazonamiento verbal.\r\nDestreza en el uso de herramientas de las tecnologías de información\r\nAfinidad y habilidad por la tecnología, la lectura, apertura al cambio y a nuevas ideas.\r\nEspíritu creativo, innovador y emprendedor.\r\nPoseer valores como persistencia, paciencia, responsabilidad, honestidad y espíritu de servicio que permita la convivencia social.\r\nCompromiso para la búsqueda de soluciones a su entorno con la implementación de las tecnologías de la información.', 'Diseñar, configurar y administrar redes computacionales aplicando las normas y estándares vigentes.\r\nDesarrollar, implementar y administrar software de sistemas o de aplicación que cumpla con los estándares de calidad con el fin de apoyar la productividad y competitividad de las organizaciones.\r\nCoordinar y participar en proyectos interdisciplinarios.\r\nDiseñar e implementar interfaces hombre-máquina y máquina-máquina para la automatización de sistemas.\r\nIdentificar y comprender las tecnologías de hardware para proponer, desarrollar y mantener aplicaciones eficientes.\r\nDiseñar, desarrollar y administrar bases de datos conforme a requerimientos definidos, normas organizacionales de manejo y seguridad de la información, utilizando tecnologías emergentes.\r\nIntegrar soluciones computacionales con diferentes tecnologías, plataformas o dispositivos.\r\nDesarrollar una visión empresarial para detectar áreas de oportunidad que le permitan emprender y desarrollar proyectos aplicando las tecnologías de la información y comunicación.\r\nDesempeñar sus actividades profesionales considerando los aspectos legales, éticos, sociales y de desarrollo sustentable.\r\nPoseer habilidades metodológicas de investigación que fortalezcan el desarrollo cultural, científico y tecnológico en el ámbito de sistemas computacionales y disciplinas afines.\r\nSeleccionar y aplicar herramientas matemáticas para el modelado, diseño y desarrollo de tecnología computacional.', 'Descripción campo laboral', 1),
(2, 'Gestión Empresarial', 'La Ingeniería en Gestión Empresarial del Instituto Tecnológico Superior de Zongolica se inicia en el año 2009 con una matrícula de 41 alumnos; al ser ésta una ingeniería nueva, se plantean cuáles serán los principales objetivos, qué se pretende lograr y cómo hacer para alcanzarlos.', 'Formar integralmente profesionales que contribuyan a la gestión de empresas e innovación de procesos emprendinnovadores; así como al diseño, implementación y desarrollo de sistemas estratégicos de negocios, optimizando recursos en un entorno global, con ética y responsabilidad social.', 'Formar profesionistas en gestión empresarial con un enfoque emprendinnovador, creativo y sustentable, que coadyuven de manera eficiente y eficaz hacia el desarrollo económico de la zona de influencia del ITSZ.\r\n', 'Ser un programa educativo líder a nivel nacional por su excelencia profesional, mediante la mejora continua, impulsando el desarrollo sustentable emprendeinnovador, que permita elevar la calidad de vida de la sociedad.', 'Un ingeniero en gestión empresarial fomenta y promueve el cambio organizacional en las instituciones, crea nuevas empresas aplicando los conocimientos adquiridos en sociología, derecho laboral, publicidad, procesos, calidad, mercadotecnia y comercio internacional, entre otras. Para diseñar procesos de mayor eficiencia, en áreas relacionadas con ventas, compras, producción, planeación y vinculación, manejo de roles de grupo y quipos de trabajo.', 'Desarrollar y aplicar habilidades directivas y la ingeniería en el diseño, creación, gestión, desarrollo, fortalecimiento emprendinnovador de las organizaciones, con una orientación sistémica y sustentable para la toma de decisiones en forma efectiva.\r\n\r\nDiseñar e innovar estructuras administrativas y procesos, con base en las necesidades de las organizaciones para competir eficientemente en mercados globales.', 'Utilizar las nuevas tecnologías de información en la organización, para optimizar los procesos de comunicación y eficientar la toma de decisiones.', 'Campo Laboral', 1),
(3, 'Innovación Agrícola', 'La situación de la región en donde nos encontramos ubicados es de pobreza extrema, lo que presenta el mayor de los retos en la IIAS, teniendo como meta formar Ingenieros en Innovación Agrícola Sustentable comprometidos socialmente y con sólida cultura científico tecnológica.', 'Formar profesionistas analíticos y críticos, comprometidos socialmente y con sólida cultura científico tecnológica, que les permita la planeación del desarrollo regional en el contexto de la sustentabilidad, para realizar investigación, validación, transferencia, adaptación, producción e innovación agrícola.', 'La Ingeniería en Innovación Agrícola Sustentable forma profesionistas, analíticos y críticos, que les permita la planeación del desarrollo regional en el contexto de la sustentabilidad.', 'Ser la ingeniería líder a nivel nacional formadora de profesionistas, que incidan en la innovación sustentable, científica y tecnológica, para mejorar la calidad de vida del país.', 'Porque', 'El aspirante a ingresar a la carrera de Ingeniería en Innovación Agrícola Sustentable es recomendable que tenga los siguientes conocimientos, habilidades y actitudes.', 'Diseñar, crear, instalar, operar y proporcionar mantenimiento a empresas agrícolas dentro de un marco de desarrollo regional, nacional e internacional.', 'Campo laboral', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especialidad`
--

DROP TABLE IF EXISTS `especialidad`;
CREATE TABLE IF NOT EXISTS `especialidad` (
  `id_especialidad` int(10) DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `mision` varchar(500) DEFAULT NULL,
  `vision` varchar(500) DEFAULT NULL,
  `objetivo` varchar(500) DEFAULT NULL,
  `id_oferta` int(10) DEFAULT NULL,
  `carrerasid_carrera` int(10) NOT NULL,
  KEY `FKespecialid588327` (`carrerasid_carrera`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `especialidad`
--

INSERT INTO `especialidad` (`id_especialidad`, `nombre`, `mision`, `vision`, `objetivo`, `id_oferta`, `carrerasid_carrera`) VALUES
(3, '3', '3', '3', '3', 3, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `extensiones`
--

DROP TABLE IF EXISTS `extensiones`;
CREATE TABLE IF NOT EXISTS `extensiones` (
  `id_ext` int(10) NOT NULL AUTO_INCREMENT,
  `id_institucion` int(10) NOT NULL,
  `nombre_extesion` varchar(50) DEFAULT NULL,
  `direccion` varchar(50) DEFAULT NULL,
  `latitud` varchar(20) DEFAULT NULL,
  `longitud` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_ext`),
  KEY `FKextensione815007` (`id_institucion`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `extensiones`
--

INSERT INTO `extensiones` (`id_ext`, `id_institucion`, `nombre_extesion`, `direccion`, `latitud`, `longitud`) VALUES
(1, 1, 'Nogales', 'Km 4 Carretera a la Compañia S/N, Tepetlitlanapa.', '18.6476477', '-97.0063614');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `instituciones`
--

DROP TABLE IF EXISTS `instituciones`;
CREATE TABLE IF NOT EXISTS `instituciones` (
  `id_institucion` int(10) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `pagina_web` varchar(100) DEFAULT NULL,
  `link_video_inst` varchar(200) DEFAULT NULL,
  `direccion` varchar(500) DEFAULT NULL,
  `localidad` varchar(50) DEFAULT NULL,
  `municipio` varchar(50) DEFAULT NULL,
  `modalidad` varchar(50) DEFAULT NULL,
  `turno` varchar(20) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `correo_contacto` varchar(50) DEFAULT NULL,
  `cupo_total` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_institucion`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `instituciones`
--

INSERT INTO `instituciones` (`id_institucion`, `nombre`, `pagina_web`, `link_video_inst`, `direccion`, `localidad`, `municipio`, `modalidad`, `turno`, `telefono`, `correo_contacto`, `cupo_total`) VALUES
(1, 'Instituto Tecnológico Superior de Zongolica', 'https://zongolica.tecnm.mx/', 'https://www.youtube.com/watch?v=MypzBpE-nu0', 'Km 4 Carretera a la Compañia S/N.', 'Tepetlitlanapa', 'Zongolica', 'Mixto', 'Matutino', '2712111687', 'direccion@zongolica.tecnm.mx', 100);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `multimedia`
--

DROP TABLE IF EXISTS `multimedia`;
CREATE TABLE IF NOT EXISTS `multimedia` (
  `id_multimedia` int(10) NOT NULL AUTO_INCREMENT,
  `nombre_recurso` varchar(100) DEFAULT NULL,
  `ruta` varchar(500) DEFAULT NULL,
  `ext_recurso` varchar(10) DEFAULT NULL,
  `institucionesid_institucion` int(10) NOT NULL,
  PRIMARY KEY (`id_multimedia`),
  KEY `FKmultimedia63071` (`institucionesid_institucion`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `multimedia`
--

INSERT INTO `multimedia` (`id_multimedia`, `nombre_recurso`, `ruta`, `ext_recurso`, `institucionesid_institucion`) VALUES
(59, 'imagen insertada', '../files/images/5fe8222cc533f.jpeg', '1', 1),
(60, 'Solo se actualizo imagen', '../files/images/5fe8226b0e51e.jpeg', '1', 1),
(62, 'imagen', '../files/images/5fe95d0972559.jpeg', '1', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oferta_extension`
--

DROP TABLE IF EXISTS `oferta_extension`;
CREATE TABLE IF NOT EXISTS `oferta_extension` (
  `id_ofe_ext` int(10) NOT NULL AUTO_INCREMENT,
  `id_carrera` int(10) NOT NULL,
  `id_ext` int(10) NOT NULL,
  `cupo_x_carrera` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_ofe_ext`),
  KEY `FKoferta_ext48674` (`id_carrera`),
  KEY `FKoferta_ext408945` (`id_ext`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `oferta_extension`
--

INSERT INTO `oferta_extension` (`id_ofe_ext`, `id_carrera`, `id_ext`, `cupo_x_carrera`) VALUES
(1, 1, 1, 99);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planes_estudio`
--

DROP TABLE IF EXISTS `planes_estudio`;
CREATE TABLE IF NOT EXISTS `planes_estudio` (
  `id_plan` int(10) NOT NULL AUTO_INCREMENT,
  `asignatura` varchar(40) DEFAULT NULL,
  `clave` varchar(40) DEFAULT NULL,
  `tipo_asignatura` varchar(40) DEFAULT NULL,
  `ruta_pdf` varchar(100) DEFAULT NULL,
  `id_carrera` int(10) NOT NULL,
  PRIMARY KEY (`id_plan`),
  KEY `FKplanes_est839306` (`id_carrera`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `planes_estudio`
--

INSERT INTO `planes_estudio` (`id_plan`, `asignatura`, `clave`, `tipo_asignatura`, `ruta_pdf`, `id_carrera`) VALUES
(1, 'Programación WEB', 'AEB1055G', 'Programación', '../files/pdf/5fe9336dd9cf9.pdf', 1),
(2, 'Administración de redes', 'SCA1002G', 'Adminitración', '../files/pdf/5fe933ff51415.pdf', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` int(10) NOT NULL AUTO_INCREMENT,
  `id_institucion` int(10) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `pass` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `id_institucion`, `correo`, `pass`) VALUES
(1, 1, 'admin@admin.com', '$2y$10$Nwg9/Fd/tEQC01BVQxaTNeQjYniUkUlTPiXKGrr.E8NdomQ5g77PO');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `carreras`
--
ALTER TABLE `carreras`
  ADD CONSTRAINT `FKcarreras18801` FOREIGN KEY (`institucionesid_institucion`) REFERENCES `instituciones` (`id_institucion`);

--
-- Filtros para la tabla `especialidad`
--
ALTER TABLE `especialidad`
  ADD CONSTRAINT `FKespecialid588327` FOREIGN KEY (`carrerasid_carrera`) REFERENCES `carreras` (`id_carrera`);

--
-- Filtros para la tabla `extensiones`
--
ALTER TABLE `extensiones`
  ADD CONSTRAINT `FKextensione815007` FOREIGN KEY (`id_institucion`) REFERENCES `instituciones` (`id_institucion`);

--
-- Filtros para la tabla `multimedia`
--
ALTER TABLE `multimedia`
  ADD CONSTRAINT `FKmultimedia63071` FOREIGN KEY (`institucionesid_institucion`) REFERENCES `instituciones` (`id_institucion`);

--
-- Filtros para la tabla `oferta_extension`
--
ALTER TABLE `oferta_extension`
  ADD CONSTRAINT `FKoferta_ext408945` FOREIGN KEY (`id_ext`) REFERENCES `extensiones` (`id_ext`),
  ADD CONSTRAINT `FKoferta_ext48674` FOREIGN KEY (`id_carrera`) REFERENCES `carreras` (`id_carrera`);

--
-- Filtros para la tabla `planes_estudio`
--
ALTER TABLE `planes_estudio`
  ADD CONSTRAINT `FKplanes_est839306` FOREIGN KEY (`id_carrera`) REFERENCES `carreras` (`id_carrera`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
